#!/bin/bash


ORIGEN=$1
DESTINO=$2


if [ "$1" == "-help" ]; then
    echo "=========================================================="
    echo "Script de Backup Automatizado"
    echo "=========================================================="
    echo "Uso correcto: $0 [origen] [destino]"
    echo "Ejemplo:      $0 /var/log /backup_dir"
    echo "=========================================================="
    exit 0
fi


if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen ($ORIGEN) no existe o no está disponible."
    exit 1
fi


if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino ($DESTINO) no existe o no está disponible."
    exit 1
fi


FECHA=`date +%Y%m%d`


NOMBRE_DIR=`basename "$ORIGEN"`


NOMBRE_ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"


# -c: crear archivo, -z: comprimir con gzip, -f: especificar el nombre del archivo
tar -czf "$DESTINO/$NOMBRE_ARCHIVO" "$ORIGEN"

echo "Backup realizado con éxito en: $DESTINO/$NOMBRE_ARCHIVO"
