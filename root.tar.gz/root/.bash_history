history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
clear
vim /etc/hostname
shutdown now -r
clear
vim /etc/network/interfaces
systemctl restart networking
clear
vim /etc/apt/sources.list
clear
apt updates
clear
apt update
vim /etc/apt/sources.list
shutdown now -r
clear
apt update
apt full-upgrade
reboot
shutdown now 
lsb_release -a 
apt install nano
apt install nano
clear
vim /etc/network/interfaces
reboot
clear
apt install nano
clear
apt update
cat /etc/network/interfaces
vim  /etc/network/interfaces
reboot
apt update
clear
vim  /etc/network/interfaces
reboot
clear
apt update
clear
ping 10.129.22.174
vim  /etc/network/interfaces
reboot
apt update
clear
vim  /etc/network/interfaces
clear
vim /etc/ssh/sshd_config
vim /etc/.ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
vim /etc/network/interfaces
systemctl restart networking
apt update
vim /etc/resolv.conf
clear
reboot
apt update
clear
apt install nano
nano /etc/network/interfaces
clear
apt install openssh-server
clear
nano /etc/ssh/sshd_config
clear
nano /etc/ssh/sshd_config
nano /etc/.ssh/sshd_config
ls /etc/ssh
ls /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
reboot
nano /etc/ssh/sshd_config
apt install openssh-server
nano /etc/ssh/sshd_config
clear
dpkg-reconfigure openssh-server
nano /etc/ssh/sshd_config
dpkg-reconfigure openssh-server
apt purge openssh-server openssh-client -y
apt autoremove -y
rm -rf /etc/ssh
clear
apt install openssh-server
nano /etc/ssh/sshd_config
clear
ip a
reboot
clear
mkdir -p /root/.ssh
nano /root/.ssh/authorized_keys
clear
mkdir /etc/.ssh/authorized_keys
touch /etc/.ssh/authorized_keys
ls /etc/.ssh
ls -a /etc/.ssh
ls -a /etc
ls -a /etc | grep .ssh
clear
cat /etc/.ssh/autorized_keys
reboot
cat /etc/.ssh/autorized_keys
clesr
clear
ls -a /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
shutdown now
clear
lsblk
fdisk /dev/sdc
clear
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
clear
mkdir /www_dir /backup_dir
blkid
clear
nano /etc/fstab
nano /etc/fstab
clear
mount -a
systemctl daemon-reload
clear
mount -a
df -h
clear
apt update
clear
apt install apache2 -y
clear
apt install php libapache2-mod-php -y
clear
cp /root/index.php /var/www/html/
ls /root
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ip a
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
reboot
clear
clear
ip a
clear
rm /var/www/html/index.html
ls /var/www/html/
clear
ls /var/www/html/
rm /var/www/html/index.php
cp /root/index.php /var/www/html/
systemctl restart apache2
systemctl restart apache2
sudo chmod 644 imagen.png
systemctl restart apache2
clear
apt update
clear
apt install mariadb-server -y
clear
sudo mysql_secure_installation
clear
sudo mysql_secure_installation
clear
systemctl stop mariadb
apt purge mariadb-server mariadb-client -y
clear
rm -rf /etc/mysql
rm -rf /var/lib/mysql
apt autoremove -y
clear
apt update
clear
apt install mariadb-server -y
systemctl status mariadb
reboot
clear
apt install mariadb-server
dpkg --configure -a
apt-get install -f
clear
ls -l /etc/mysql
clear
touch /etc/mysql/mariadb.conf
rm -rf /etc/mysql/mariadb.conf
clear
touch /etc/mysql/mariadb.cnf
ls -l /etc/mysql
clear
dpkg --configure -a
apt --fix-broken install
clear
apt install mariadb-server
clear
systemctl status mariadb
q
clear
mysql_secure_installation
clear
mysql
clear
ls /root
ls /root
clear
mysql < /root/db.sql
clear
mysql
clear
clear
ls -root
ls /www_dir/
cp /root/index.php /www_dir/
cp /root/logo.png /www_dir/
ls /www_dir/
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
clear
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
nano/etc/setup
clear
nano /etc/fstab
clear
systemctl restart apache2
clear
cat /proc/partitions > /opt/particion 
cat /opt/particion
clear
shutdown now
clear
nano /etc/network/interfaces
reboot
clear
systemctl ssh status
systemctl status ssh
clear
ip a
apt upddate
apt update
clear
nano /etc/network/interfaces
nano /etc/resolv.conf
reboot
clear
mkdir -p /opt/scripts
touch /opt/scripts/backup_full.sh 
chmod +x /opt/scripts/backup_full.sh 
nano /opt/scripts/backup_full.sh 
