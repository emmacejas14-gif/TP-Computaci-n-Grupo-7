<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabajo de Computación Aplicada</title>
    <style>
        /* Estilos básicos para que la web se vea limpia y ordenada */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 2rem 1rem;
        }

        main {
            flex: 1;
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
        }

        .img-container {
            margin: 2rem 0;
        }

        .img-container img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
        }

        .info-php {
            background-color: #e8f4f8;
            border-left: 5px solid #3498db;
            padding: 1rem;
            margin-top: 2rem;
            border-radius: 4px;
            font-size: 0.95rem;
        }

        footer {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 1rem;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>

    <header>
        <h1>Proyecto de Servidor Web</h1>
        <p>Asignatura: Computación Aplicada</p>
    </header>

    <main>
        <h2>Bienvenido a mi sitio web en Apache</h2>
        <p>Esta página está siendo procesada por el servidor Apache y utiliza PHP para mostrar contenido dinámico básico.</p>
        
        <div class="img-container">
            <img src="imagen.png" alt="Imagen del proyecto Computación Aplicada">
        </div>

        <div class="info-php">
            <h3>Contenido generado con PHP:</h3>
            <?php
                // Definimos variables simples
                $fecha_actual = date("d/m/Y");
                $hora_actual = date("H:i:s");
                
                echo "<p><strong>Fecha del servidor:</strong> " . $fecha_actual . "</p>";
                echo "<p><strong>Hora del servidor:</strong> " . $hora_actual . "</p>";
                echo "<p><em>Apache y PHP están funcionando correctamente.</em></p>";
            ?>
        </div>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> - Desarrollado para Computación Aplicada</p>
    </footer>

</body>
</html>